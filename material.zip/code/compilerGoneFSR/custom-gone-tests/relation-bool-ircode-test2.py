print 4 + 5;
print 2.0 > 3.0;
