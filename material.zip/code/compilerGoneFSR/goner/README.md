Este es el compilador de ejemplo con las funcionalidades básicas
