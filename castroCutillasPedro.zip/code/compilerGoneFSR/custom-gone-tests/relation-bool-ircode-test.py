print (3 > 2) && (4 > 5); // should return false
