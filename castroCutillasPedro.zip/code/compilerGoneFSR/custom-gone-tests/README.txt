Custom Gone programs test files directory 
All this files are written by Pedro Castro
