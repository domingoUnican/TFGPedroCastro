def fun(a, b, c):
    c = 2
    return c

print(fun(1,2,3))

