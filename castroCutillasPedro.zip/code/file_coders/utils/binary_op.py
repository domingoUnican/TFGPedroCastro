def XOR(a,b):
    return (a+b)%2
 
def AND(a,b):
    return (a*b)%2
 
def NOT(a):
    return (a+1)%2
